<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Bisan Art Kitchen</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet" />
    <link href="css/all.min.css" rel="stylesheet" />
	<link href="css/templatemo-style.css" rel="stylesheet" />
</head>

<body> 

	<div class="container">
	
		<div class="placeholder">
			<div class="parallax-window" data-parallax="scroll" data-image-src="img/sea/index6.jpg">
				<div class="tm-header">
					<div class="row tm-header-inner">
						<div class="col-md-6 col-12">
							<img src="img/index10.png" alt="Logo" class="tm-site-logo" width="60px" height="60px"/> 
							<div class="tm-site-text-box">
								<h1 class="tm-site-title">Bisan Art Kitchen</h1>
								<h6 class="tm-site-description"></h6>	
							</div>
						</div>
						<nav class="col-md-6 col-12 tm-nav">
							<ul class="tm-nav-ul">
								<li class="tm-nav-li"><a href="index.html" class="tm-nav-link">Home</a></li>
								<li class="tm-nav-li"><a href="gallery.html" class="tm-nav-link">Gallery</a></li>
								<li class="tm-nav-li"><a href="kitchen.html" class="tm-nav-link">Kitchen</a></li>
								<li class="tm-nav-li"><a href="about.html" class="tm-nav-link">About</a></li>
								<li class="tm-nav-li"><a href="contact.php" class="tm-nav-link active">Contact</a></li>
							</ul>
						</nav>	
					</div>
				</div>
			</div>
		</div>

		<main>
			<header class="row tm-welcome-section">
				<h2 class="col-12 text-center tm-section-title">Contact Page</h2>
				<p class="col-12 text-center">If you have any questions or comments feel free to fill the form below and I will make sure to get back to you shortly!</p>
				<p class="col-12 text-center">Always happy to hear your feedback!</p>

			</header>

			<div class="tm-container-inner-2 tm-contact-section">
				<div class="row">
					<div class="col-md-6">
						<form action="" method="POST" class="tm-contact-form">
					        <div class="form-group">
					          <input type="text" name="name" class="form-control" placeholder="Name" required="" />
					        </div>
					        
					        <div class="form-group">
					          <input type="email" name="email" class="form-control" placeholder="Email" required="" />
					        </div>
				
					        <div class="form-group">
					          <textarea rows="5" name="message" class="form-control" placeholder="Comment or Message" required=""></textarea>
					        </div>
					
					        <div class="form-group tm-d-flex">
					          <button type="submit" class="tm-btn tm-btn-success tm-btn-right" name="submit">
					            Send
					          </button>

                              <?php

                              if(isset($_POST["submit"])){

                                    require_once("admin/baglan.php");

                                    $gelenad = $_POST["name"];
                                    $gelenemail = $_POST["email"];
                                    $gelenyorum = $_POST["message"];

                                    $YorumEkle = mysqli_query($veritabaniBaglantisi , "INSERT INTO comments(Name,Email,Comment) VALUES('$gelenad','$gelenemail','$gelenyorum')");
                                    if($YorumEkle){
                                       ?>
                                    <script>
                                    alert("successfully sent.");
                                    </script>   
                                     <?php
                                        }
                                    }
                                        ?>
					        </div>
						</form>
					</div>
					<div class="col-md-6">
						<div class="tm-address-box">
							<h4 class="tm-info-title tm-text-success">Our Address</h4>
							<address>
								Halkalı Merkez, Halkalı, 34303 Küçükçekmece/İstanbul
							</address>
							<a href="tel:080-090-0110" class="tm-contact-link">
								<i class="fas fa-phone tm-contact-icon"></i>080-090-0110
							</a>
							<a href="mailto:info@company.co" class="tm-contact-link">
								<i class="fas fa-envelope tm-contact-icon"></i>bisan.art.kitchen@outlook.com
							</a>
							<div class="tm-contact-social">
								<a href="https://fb.com/templatemo" class="tm-social-link"><i class="fab fa-facebook tm-social-icon"></i></a>
								<a href="https://twitter.com/sophiahome2" class="tm-social-link"><i class="fab fa-twitter tm-social-icon"></i></a>
								<a href="https://www.instagram.com/bisan.art.kitchen/" class="tm-social-link"><i class="fab fa-instagram tm-social-icon"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="tm-container-inner-2 tm-map-section">
				<div class="row">
					<div class="col-12">
						<div class="tm-map">
							<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12034.314502328942!2d28.779440000000005!3d41.056343!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x307336249f2c0eeb!2sProf.Dr.%20Sabahattin%20Zaim%20Anadolu%20Lisesi!5e0!3m2!1sen!2sth!4v1618653609453!5m2!1sen!2sth" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
						</div>
					</div>
				</div>
			</div>
			
		</main>

		<footer class="tm-footer text-center">
			<p>Copyright &copy; 2020 Bisan Art Kitchen</p>
		</footer>
	</div>
	<script src="js/jquery.min.js"></script>
	<script src="js/parallax.min.js"></script>
	<script>
		$(document).ready(function(){
			var acc = document.getElementsByClassName("accordion");
			var i;
			
			for (i = 0; i < acc.length; i++) {
			  acc[i].addEventListener("click", function() {
			    this.classList.toggle("active");
			    var panel = this.nextElementSibling;
			    if (panel.style.maxHeight) {
			      panel.style.maxHeight = null;
			    } else {
			      panel.style.maxHeight = panel.scrollHeight + "px";
			    }
			  });
			}	
		});
	</script>
</body>
</html>