<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Bisan Art Kitchen</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet" />
    <link href="css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="Giris_Sayfasi.css" />
</head>
<body>
    <div class="sayfa">
        <div class="sayfa">
            <img id="logo" src="index10.png" alt="Logo" class="tm-site-logo"  width="230px" height="230px">
            <div class="formAlani">
                <table>
                    <form method="POST" action="">
                        <tr>
                            <td><input type="text" placeholder="First Name" id="firstName" name="firstName"></td>
                        </tr>
                        <tr>
                            <td><input type="text" placeholder="Last Name" id="lastName" name="lastName"></td>
                        </tr>
                        <tr>
                            <td><input type="text" placeholder="Email" id="email" name="email"></td>
                        </tr>
                        <tr>
                            <td><input type="password" placeholder="Password" id="password" name="password"></td>
                        </tr>
                        <tr>
                            <td><input type="submit" value="Sign Up" id="girisButonu" name="girisButonu"></td>
                        </tr>
                    </form>
                </table>
                <p>OR <a href="GirisSayfasi.php">Login </a></p>
            </div>
        </div>
        
    </div>

    <?php
    require_once("baglan.php");
    if(isset($_POST["girisButonu"])){

        $Firstname = $_POST["firstName"];
        $Lastname = $_POST["lastName"];
        $Email = $_POST["email"];
        $Password = $_POST["password"];

        $KontrolSorgusu = mysqli_query($veritabaniBaglantisi , "SELECT * FROM users WHERE Email = '$Email'");
        $kontrolsayi = mysqli_num_rows($KontrolSorgusu);
        if($kontrolsayi == 1){?>
            <script>
            alert("Try another Email.");
        </script>
        <?php
        }
        else{

        $ElemanEklemeSorgusu = mysqli_query($veritabaniBaglantisi , "INSERT INTO users(firstName,lastName,Email,password) VALUES('$Firstname','$Lastname','$Email','$Password')");
        if($ElemanEklemeSorgusu){
            ?>
            <script>
                alert("added successfully.");
            </script>
            <?php
        }

    }

    }
    ?>
</body>
</html>