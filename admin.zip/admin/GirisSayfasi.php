<?php
require_once("baglan.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Bisan Art Kitchen</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400" rel="stylesheet" />
    <link href="css/all.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="Giris_Sayfasi.css" />
</head>
<body>
    <div class="sayfa">
        <?php 
        
        if(!(isset($_SESSION["kullanici"]))){
        ?>
        <img id="logo" src="index10.png" alt="Logo" class="tm-site-logo"  width="230px" height="230px">
        <div class="formAlani">
            <table>
                <form action="uyegiris.php" method="post">
                    <tr>
                        <td><input type="text" placeholder="Email" id="email" name="email"></td>
                    </tr>
                    <tr>
                        <td><input type="password" placeholder="Password" id="password" name="password"></td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="Login" id="girisButonu"></td>
                    </tr>
                </form>
            </table>
            <p>OR <a href="Eleman_Ekle.php">Sign Up </a></p>

        </div>
        <?php 
        }
        ?>
    </div>
</body>
</html>