<?php

require_once("baglan.php");

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
	<link href="comments.css" rel="stylesheet" />
	<title></title>
</head>
<body>

	<div class="filter">
		
	</div>

	<table style="position: center; width: 70%" >
		<tr>
			<th>#</th>
			<th>Name</th>
			<th>Email</th>
			<th>Comment</th>
		</tr>
        <?php
        $YorumlariGetirSorgusu = mysqli_query($veritabaniBaglantisi , "SELECT * FROM comments");
        $YorumSayisi = mysqli_num_rows($YorumlariGetirSorgusu);
        while($Yorumlar = mysqli_fetch_assoc($YorumlariGetirSorgusu)){
        ?>
		<tr>
			<td><?php echo $Yorumlar["id"]; ?></td>
			<td><?php echo $Yorumlar["Name"]; ?></td>
			<td><?php echo $Yorumlar["Email"]; ?></td>
			<td style = "width:40%; height:auto "><?php echo $Yorumlar["Comment"]; ?></td>
		</tr>
        <?php } ?>

	</table>
</body>
</html>